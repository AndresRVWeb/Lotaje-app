import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET - Obtener todos los períodos
export async function GET() {
  try {
    let periods = await db.period.findMany({
      orderBy: { createdAt: 'desc' },
      include: {
        _count: {
          select: { trades: true }
        }
      }
    })
    
    // Si no hay períodos, crear el primero
    if (periods.length === 0) {
      const newPeriod = await db.period.create({
        data: {
          name: 'Período 1',
          isActive: true
        },
        include: {
          _count: {
            select: { trades: true }
          }
        }
      })
      periods = [newPeriod]
    }
    
    return NextResponse.json(periods)
  } catch (error) {
    return NextResponse.json({ error: 'Error al obtener períodos' }, { status: 500 })
  }
}

// POST - Crear un nuevo período (reiniciar)
export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { name } = body

    // Desactivar el período activo actual
    const activePeriod = await db.period.findFirst({
      where: { isActive: true }
    })
    
    if (activePeriod) {
      await db.period.update({
        where: { id: activePeriod.id },
        data: { 
          isActive: false,
          endDate: new Date()
        }
      })
    }

    // Obtener el número del próximo período
    const periodCount = await db.period.count()
    const periodName = name || `Período ${periodCount + 1}`

    // Crear nuevo período
    const newPeriod = await db.period.create({
      data: {
        name: periodName,
        isActive: true
      },
      include: {
        _count: {
          select: { trades: true }
        }
      }
    })

    return NextResponse.json(newPeriod)
  } catch (error) {
    return NextResponse.json({ error: 'Error al crear período' }, { status: 500 })
  }
}
