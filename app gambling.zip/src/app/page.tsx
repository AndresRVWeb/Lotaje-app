"use client";

import { useState, useEffect, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { 
  Trash2, 
  AlertTriangle, 
  CheckCircle, 
  TrendingUp, 
  BarChart3, 
  Plus, 
  RefreshCw,
  Calendar,
  History
} from "lucide-react";

interface Asset {
  id: string;
  symbol: string;
  name: string;
  category: string;
  isActive: boolean;
}

interface Period {
  id: string;
  name: string;
  startDate: string;
  endDate: string | null;
  isActive: boolean;
  _count?: { trades: number };
}

interface Trade {
  id: string;
  assetId: string;
  periodId: string;
  lotSize: number;
  notes: string | null;
  createdAt: string;
  asset: Asset;
  period: Period;
}

interface AssetStats {
  assetId: string;
  asset: Asset;
  trades: Trade[];
  mostUsedLot: number;
  minAllowed: number;
  maxAllowed: number;
}

interface TradeWithStatus extends Trade {
  isViolation: boolean;
  violationType: "none" | "above" | "below" | null;
  assetStats: AssetStats | null;
}

const CATEGORY_LABELS: Record<string, string> = {
  forex: "Forex",
  indices: "Índices",
  commodities: "Materias Primas",
  crypto: "Criptomonedas",
};

export default function TradingJournal() {
  const [trades, setTrades] = useState<Trade[]>([]);
  const [assets, setAssets] = useState<Asset[]>([]);
  const [periods, setPeriods] = useState<Period[]>([]);
  const [selectedAssetId, setSelectedAssetId] = useState("");
  const [selectedPeriodId, setSelectedPeriodId] = useState("");
  const [lotSize, setLotSize] = useState("");
  const [notes, setNotes] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [assetStatsMap, setAssetStatsMap] = useState<Map<string, AssetStats>>(new Map());
  const [isNewAssetOpen, setIsNewAssetOpen] = useState(false);
  const [isNewPeriodOpen, setIsNewPeriodOpen] = useState(false);
  const [newAssetSymbol, setNewAssetSymbol] = useState("");
  const [newAssetName, setNewAssetName] = useState("");
  const [newAssetCategory, setNewAssetCategory] = useState("forex");
  const [newPeriodName, setNewPeriodName] = useState("");
  const { toast } = useToast();

  // Fetch assets
  const fetchAssets = useCallback(async () => {
    try {
      const response = await fetch("/api/assets");
      const data = await response.json();
      setAssets(Array.isArray(data) ? data : []);
    } catch {
      toast({
        title: "Error",
        description: "No se pudieron cargar los activos",
        variant: "destructive",
      });
      setAssets([]);
    }
  }, [toast]);

  // Fetch periods
  const fetchPeriods = useCallback(async () => {
    try {
      const response = await fetch("/api/periods");
      const data = await response.json();
      const periodsArray = Array.isArray(data) ? data : [];
      setPeriods(periodsArray);
      
      // Set active period as selected
      const activePeriod = periodsArray.find((p: Period) => p.isActive);
      if (activePeriod) {
        setSelectedPeriodId(activePeriod.id);
      }
    } catch {
      toast({
        title: "Error",
        description: "No se pudieron cargar los períodos",
        variant: "destructive",
      });
      setPeriods([]);
    }
  }, [toast]);

  // Fetch trades
  const fetchTrades = useCallback(async () => {
    try {
      const url = selectedPeriodId 
        ? `/api/trades?periodId=${selectedPeriodId}`
        : "/api/trades";
      const response = await fetch(url);
      const data = await response.json();
      setTrades(Array.isArray(data) ? data : []);
    } catch {
      toast({
        title: "Error",
        description: "No se pudieron cargar los trades",
        variant: "destructive",
      });
      setTrades([]);
    }
  }, [selectedPeriodId, toast]);

  useEffect(() => {
    fetchAssets();
    fetchPeriods();
  }, [fetchAssets, fetchPeriods]);

  useEffect(() => {
    if (selectedPeriodId) {
      fetchTrades();
    }
  }, [selectedPeriodId, fetchTrades]);

  // Calculate asset statistics when trades change
  useEffect(() => {
    const statsMap = new Map<string, AssetStats>();
    
    // Group trades by asset
    const assetGroups = new Map<string, Trade[]>();
    trades.forEach((trade) => {
      const existing = assetGroups.get(trade.assetId) || [];
      existing.push(trade);
      assetGroups.set(trade.assetId, existing);
    });

    // Calculate statistics for each asset
    assetGroups.forEach((assetTrades, assetId) => {
      // Find the most used lot size (mode)
      const lotCounts = new Map<number, number>();
      assetTrades.forEach((trade) => {
        const count = lotCounts.get(trade.lotSize) || 0;
        lotCounts.set(trade.lotSize, count + 1);
      });

      let mostUsedLot = 0;
      let maxCount = 0;
      lotCounts.forEach((count, lot) => {
        if (count > maxCount) {
          maxCount = count;
          mostUsedLot = lot;
        }
      });

      // If there's a tie, use the highest lot size among the most frequent
      lotCounts.forEach((count, lot) => {
        if (count === maxCount && lot > mostUsedLot) {
          mostUsedLot = lot;
        }
      });

      const asset = assetTrades[0].asset;
      statsMap.set(assetId, {
        assetId,
        asset,
        trades: assetTrades,
        mostUsedLot,
        minAllowed: mostUsedLot / 3.5,
        maxAllowed: mostUsedLot * 3.5,
      });
    });

    setAssetStatsMap(statsMap);
  }, [trades]);

  // Add new asset
  const handleAddAsset = async () => {
    if (!newAssetSymbol || !newAssetName || !newAssetCategory) return;

    try {
      const response = await fetch("/api/assets", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          symbol: newAssetSymbol.toUpperCase(),
          name: newAssetName,
          category: newAssetCategory,
        }),
      });

      if (response.ok) {
        const newAsset = await response.json();
        setAssets((prev) => [...prev, newAsset].sort((a, b) => {
          if (a.category !== b.category) return a.category.localeCompare(b.category);
          return a.symbol.localeCompare(b.symbol);
        }));
        setNewAssetSymbol("");
        setNewAssetName("");
        setNewAssetCategory("forex");
        setIsNewAssetOpen(false);
        toast({
          title: "Activo añadido",
          description: `${newAsset.symbol} ha sido añadido a la lista`,
        });
      }
    } catch {
      toast({
        title: "Error",
        description: "No se pudo añadir el activo",
        variant: "destructive",
      });
    }
  };

  // Create new period
  const handleCreatePeriod = async () => {
    try {
      const response = await fetch("/api/periods", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: newPeriodName || undefined }),
      });

      if (response.ok) {
        const newPeriod = await response.json();
        setPeriods((prev) => [newPeriod, ...prev.map(p => ({ ...p, isActive: false }))]);
        setSelectedPeriodId(newPeriod.id);
        setNewPeriodName("");
        setIsNewPeriodOpen(false);
        toast({
          title: "Nuevo período iniciado",
          description: `Período "${newPeriod.name}" creado. El cálculo de gambling se ha reiniciado.`,
        });
      }
    } catch {
      toast({
        title: "Error",
        description: "No se pudo crear el nuevo período",
        variant: "destructive",
      });
    }
  };

  // Add trade
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedAssetId || !selectedPeriodId || !lotSize) return;

    setIsLoading(true);
    try {
      const response = await fetch("/api/trades", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          assetId: selectedAssetId,
          periodId: selectedPeriodId,
          lotSize: parseFloat(lotSize),
          notes,
        }),
      });

      if (response.ok) {
        const newTrade = await response.json();
        setTrades((prev) => [newTrade, ...prev]);
        setSelectedAssetId("");
        setLotSize("");
        setNotes("");
        toast({
          title: "Trade añadido",
          description: `Trade de ${newTrade.asset.symbol} con ${newTrade.lotSize} lotes`,
        });
      } else {
        throw new Error("Error al crear trade");
      }
    } catch {
      toast({
        title: "Error",
        description: "No se pudo añadir el trade",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Delete trade
  const handleDelete = async (id: string) => {
    try {
      const response = await fetch(`/api/trades/${id}`, {
        method: "DELETE",
      });

      if (response.ok) {
        setTrades((prev) => prev.filter((t) => t.id !== id));
        toast({
          title: "Trade eliminado",
          description: "El trade ha sido eliminado",
        });
      }
    } catch {
      toast({
        title: "Error",
        description: "No se pudo eliminar el trade",
        variant: "destructive",
      });
    }
  };

  // Get trade status based on gambling rule
  const getTradeStatus = (trade: Trade): TradeWithStatus => {
    const stats = assetStatsMap.get(trade.assetId);
    if (!stats || stats.trades.length < 2) {
      return {
        ...trade,
        isViolation: false,
        violationType: null,
        assetStats: stats || null,
      };
    }

    const { minAllowed, maxAllowed } = stats;
    const isAbove = trade.lotSize > maxAllowed;
    const isBelow = trade.lotSize < minAllowed;

    return {
      ...trade,
      isViolation: isAbove || isBelow,
      violationType: isAbove ? "above" : isBelow ? "below" : "none",
      assetStats: stats,
    };
  };

  // Format number for display
  const formatLot = (num: number) => {
    return num.toFixed(4);
  };

  // Format date
  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString("es-ES", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  // Get unique assets for summary
  const assetsInPeriod = Array.from(assetStatsMap.values()).sort((a, b) => 
    a.asset.symbol.localeCompare(b.asset.symbol)
  );

  // Group assets by category for select
  const assetsByCategory = (assets || []).reduce((acc, asset) => {
    if (!acc[asset.category]) acc[asset.category] = [];
    acc[asset.category].push(asset);
    return acc;
  }, {} as Record<string, Asset[]>);

  const activePeriod = periods.find(p => p.id === selectedPeriodId);

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900">
      {/* Header */}
      <header className="border-b bg-white/80 dark:bg-slate-900/80 backdrop-blur-sm sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-emerald-500 rounded-lg">
                <TrendingUp className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-slate-900 dark:text-white">
                  Diario de Trading
                </h1>
                <p className="text-sm text-slate-500 dark:text-slate-400">
                  Control de reglas de gambling (3.5x) por período
                </p>
              </div>
            </div>
            
            {/* Period Selector */}
            <div className="flex items-center gap-3">
              <Select value={selectedPeriodId} onValueChange={setSelectedPeriodId}>
                <SelectTrigger className="w-[180px]">
                  <Calendar className="w-4 h-4 mr-2" />
                  <SelectValue placeholder="Seleccionar período" />
                </SelectTrigger>
                <SelectContent>
                  {periods.map((period) => (
                    <SelectItem key={period.id} value={period.id}>
                      <div className="flex items-center gap-2">
                        <span>{period.name}</span>
                        {period.isActive && (
                          <Badge variant="secondary" className="text-xs">Activo</Badge>
                        )}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              
              <Dialog open={isNewPeriodOpen} onOpenChange={setIsNewPeriodOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline" className="gap-2">
                    <RefreshCw className="w-4 h-4" />
                    Nuevo Período
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Iniciar Nuevo Período</DialogTitle>
                    <DialogDescription>
                      Al crear un nuevo período, los cálculos de gambling se reiniciarán.
                      Los trades anteriores se conservarán en el período anterior.
                    </DialogDescription>
                  </DialogHeader>
                  <div className="py-4">
                    <Label htmlFor="periodName">Nombre del período (opcional)</Label>
                    <Input
                      id="periodName"
                      placeholder="Ej: Enero 2024, Retiro #3..."
                      value={newPeriodName}
                      onChange={(e) => setNewPeriodName(e.target.value)}
                      className="mt-2"
                    />
                  </div>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setIsNewPeriodOpen(false)}>
                      Cancelar
                    </Button>
                    <Button onClick={handleCreatePeriod}>
                      Crear Período
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 container mx-auto px-4 py-6 space-y-6">
        {/* Info Banner */}
        <Card className="border-amber-200 bg-amber-50 dark:bg-amber-950/20 dark:border-amber-800">
          <CardContent className="py-4">
            <div className="flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 text-amber-600 dark:text-amber-400 mt-0.5 shrink-0" />
              <div className="text-sm">
                <p className="font-medium text-amber-800 dark:text-amber-200">
                  Regla de Gambling por Período
                </p>
                <p className="text-amber-700 dark:text-amber-300">
                  Cada activo no puede tener un trade que supere <strong>3.5x</strong> por encima ni por debajo del lotaje más usado 
                  <strong>dentro del período actual</strong>. Al hacer un retiro, crea un nuevo período para reiniciar los cálculos.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Current Period Info */}
        {activePeriod && (
          <Card>
            <CardContent className="py-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <History className="w-5 h-5 text-slate-500" />
                  <div>
                    <p className="font-medium">Período: {activePeriod.name}</p>
                    <p className="text-sm text-slate-500">
                      Iniciado: {formatDate(activePeriod.startDate)}
                      {activePeriod.endDate && ` | Finalizado: ${formatDate(activePeriod.endDate)}`}
                    </p>
                  </div>
                </div>
                <Badge variant={activePeriod.isActive ? "default" : "secondary"}>
                  {activePeriod.isActive ? "Activo" : "Cerrado"}
                </Badge>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Form Card */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="w-5 h-5" />
              Añadir Trade
            </CardTitle>
            <CardDescription>
              Registra un nuevo trade para el período actual
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="space-y-2">
                  <Label>Activo</Label>
                  <div className="flex gap-2">
                    <Select value={selectedAssetId} onValueChange={setSelectedAssetId}>
                      <SelectTrigger className="flex-1">
                        <SelectValue placeholder="Seleccionar..." />
                      </SelectTrigger>
                      <SelectContent>
                        {Object.entries(assetsByCategory).map(([category, categoryAssets]) => (
                          <SelectGroup key={category}>
                            <SelectLabel>{CATEGORY_LABELS[category] || category}</SelectLabel>
                            {categoryAssets.map((asset) => (
                              <SelectItem key={asset.id} value={asset.id}>
                                {asset.symbol}
                              </SelectItem>
                            ))}
                          </SelectGroup>
                        ))}
                      </SelectContent>
                    </Select>
                    
                    {/* Add new asset button */}
                    <Dialog open={isNewAssetOpen} onOpenChange={setIsNewAssetOpen}>
                      <DialogTrigger asChild>
                        <Button type="button" variant="outline" size="icon">
                          <Plus className="w-4 h-4" />
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Añadir Nuevo Activo</DialogTitle>
                          <DialogDescription>
                            Añade un activo que no está en la lista predefinida.
                          </DialogDescription>
                        </DialogHeader>
                        <div className="space-y-4 py-4">
                          <div className="space-y-2">
                            <Label htmlFor="assetSymbol">Símbolo</Label>
                            <Input
                              id="assetSymbol"
                              placeholder="Ej: BTCUSD"
                              value={newAssetSymbol}
                              onChange={(e) => setNewAssetSymbol(e.target.value.toUpperCase())}
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="assetName">Nombre completo</Label>
                            <Input
                              id="assetName"
                              placeholder="Ej: Bitcoin / Dólar"
                              value={newAssetName}
                              onChange={(e) => setNewAssetName(e.target.value)}
                            />
                          </div>
                          <div className="space-y-2">
                            <Label>Categoría</Label>
                            <Select value={newAssetCategory} onValueChange={setNewAssetCategory}>
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="forex">Forex</SelectItem>
                                <SelectItem value="indices">Índices</SelectItem>
                                <SelectItem value="commodities">Materias Primas</SelectItem>
                                <SelectItem value="crypto">Criptomonedas</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        </div>
                        <DialogFooter>
                          <Button variant="outline" onClick={() => setIsNewAssetOpen(false)}>
                            Cancelar
                          </Button>
                          <Button onClick={handleAddAsset}>
                            Añadir Activo
                          </Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="lotSize">Lotaje</Label>
                  <Input
                    id="lotSize"
                    type="number"
                    step="0.01"
                    placeholder="0.10"
                    value={lotSize}
                    onChange={(e) => setLotSize(e.target.value)}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="notes">Notas (opcional)</Label>
                  <Input
                    id="notes"
                    placeholder="Comentario..."
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                  />
                </div>
                <div className="flex items-end">
                  <Button type="submit" disabled={isLoading || !selectedAssetId || !selectedPeriodId} className="w-full">
                    {isLoading ? "Añadiendo..." : "Añadir Trade"}
                  </Button>
                </div>
              </div>
            </form>
          </CardContent>
        </Card>

        {/* Asset Summary */}
        {assetsInPeriod.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>Resumen por Activo - {activePeriod?.name || "Período"}</CardTitle>
              <CardDescription>
                Estadísticas de lotaje más usado y rangos permitidos
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {assetsInPeriod.map((stat) => {
                  const violationsCount = stat.trades.filter((t) => {
                    const status = getTradeStatus(t);
                    return status.isViolation;
                  }).length;

                  return (
                    <div
                      key={stat.assetId}
                      className="p-4 rounded-lg border bg-slate-50 dark:bg-slate-800/50"
                    >
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-bold text-lg">{stat.asset.symbol}</span>
                        <Badge variant={violationsCount > 0 ? "destructive" : "secondary"}>
                          {stat.trades.length} trades
                        </Badge>
                      </div>
                      <div className="space-y-1 text-sm">
                        <div className="flex justify-between">
                          <span className="text-slate-500">Lotaje más usado:</span>
                          <span className="font-medium">{formatLot(stat.mostUsedLot)}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-500">Mínimo (÷3.5):</span>
                          <span className="font-medium text-orange-600 dark:text-orange-400">
                            {formatLot(stat.minAllowed)}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-500">Máximo (×3.5):</span>
                          <span className="font-medium text-orange-600 dark:text-orange-400">
                            {formatLot(stat.maxAllowed)}
                          </span>
                        </div>
                        {violationsCount > 0 && (
                          <div className="pt-2 mt-2 border-t">
                            <span className="text-red-600 dark:text-red-400 font-medium">
                              ⚠️ {violationsCount} violación(es) detectada(s)
                            </span>
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Trades Table */}
        <Card className="flex-1">
          <CardHeader>
            <CardTitle>Lista de Trades - {activePeriod?.name || "Período"}</CardTitle>
            <CardDescription>
              {trades.length === 0
                ? "No hay trades registrados en este período"
                : `${trades.length} trade(s) en este período`}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {trades.length === 0 ? (
              <div className="text-center py-12 text-slate-500">
                <BarChart3 className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>No hay trades en este período.</p>
                <p className="text-sm">Añade tu primer trade arriba.</p>
              </div>
            ) : (
              <ScrollArea className="h-[400px]">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Estado</TableHead>
                      <TableHead>Activo</TableHead>
                      <TableHead>Lotaje</TableHead>
                      <TableHead>Rango Permitido</TableHead>
                      <TableHead>Notas</TableHead>
                      <TableHead>Fecha</TableHead>
                      <TableHead className="text-right">Acciones</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {trades.map((trade) => {
                      const tradeWithStatus = getTradeStatus(trade);
                      const stats = tradeWithStatus.assetStats;

                      return (
                        <TableRow
                          key={trade.id}
                          className={
                            tradeWithStatus.isViolation
                              ? "bg-red-50 dark:bg-red-950/20"
                              : ""
                          }
                        >
                          <TableCell>
                            {tradeWithStatus.isViolation ? (
                              <Badge variant="destructive" className="gap-1">
                                <AlertTriangle className="w-3 h-3" />
                                {tradeWithStatus.violationType === "above"
                                  ? "Excede"
                                  : "Muy bajo"}
                              </Badge>
                            ) : stats ? (
                              <Badge
                                variant="secondary"
                                className="bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-400 gap-1"
                              >
                                <CheckCircle className="w-3 h-3" />
                                OK
                              </Badge>
                            ) : (
                              <Badge variant="outline">Primer trade</Badge>
                            )}
                          </TableCell>
                          <TableCell>
                            <div>
                              <span className="font-medium">{trade.asset.symbol}</span>
                              <p className="text-xs text-slate-500">{trade.asset.name}</p>
                            </div>
                          </TableCell>
                          <TableCell>
                            <span
                              className={
                                tradeWithStatus.isViolation
                                  ? "font-bold text-red-600 dark:text-red-400"
                                  : ""
                              }
                            >
                              {formatLot(trade.lotSize)}
                            </span>
                          </TableCell>
                          <TableCell className="text-sm">
                            {stats ? (
                              <span className="text-slate-500">
                                {formatLot(stats.minAllowed)} - {formatLot(stats.maxAllowed)}
                              </span>
                            ) : (
                              <span className="text-slate-400">-</span>
                            )}
                          </TableCell>
                          <TableCell className="max-w-[200px] truncate text-sm text-slate-500">
                            {trade.notes || "-"}
                          </TableCell>
                          <TableCell className="text-sm text-slate-500">
                            {formatDate(trade.createdAt)}
                          </TableCell>
                          <TableCell className="text-right">
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleDelete(trade.id)}
                              className="text-slate-400 hover:text-red-500"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </ScrollArea>
            )}
          </CardContent>
        </Card>

        {/* Period History */}
        {periods.length > 1 && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <History className="w-5 h-5" />
                Historial de Períodos
              </CardTitle>
              <CardDescription>
                Todos los períodos de trading registrados
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {periods.map((period) => (
                  <div
                    key={period.id}
                    className={`flex items-center justify-between p-3 rounded-lg border ${
                      period.id === selectedPeriodId 
                        ? "bg-slate-100 dark:bg-slate-800 border-slate-300 dark:border-slate-600" 
                        : "bg-white dark:bg-slate-900"
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-3 h-3 rounded-full ${period.isActive ? "bg-emerald-500" : "bg-slate-400"}`} />
                      <div>
                        <p className="font-medium">{period.name}</p>
                        <p className="text-xs text-slate-500">
                          {formatDate(period.startDate)}
                          {period.endDate && ` - ${formatDate(period.endDate)}`}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline">
                        {period._count?.trades || 0} trades
                      </Badge>
                      {period.id !== selectedPeriodId && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => setSelectedPeriodId(period.id)}
                        >
                          Ver
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t bg-white/80 dark:bg-slate-900/80 backdrop-blur-sm mt-auto">
        <div className="container mx-auto px-4 py-4">
          <p className="text-center text-sm text-slate-500 dark:text-slate-400">
            Diario de Trading - Control de Reglas de Gambling por Período
          </p>
        </div>
      </footer>
    </div>
  );
}
// Force rebuild Tue Feb 24 17:49:49 UTC 2026
