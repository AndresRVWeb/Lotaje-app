import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET - Obtener trades (opcionalmente filtrados por período)
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const periodId = searchParams.get('periodId')
    
    const where = periodId ? { periodId } : {}
    
    const trades = await db.trade.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      include: {
        asset: true,
        period: true
      }
    })
    
    return NextResponse.json(trades)
  } catch (error) {
    return NextResponse.json({ error: 'Error al obtener trades' }, { status: 500 })
  }
}

// POST - Crear un nuevo trade
export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { assetId, periodId, lotSize, notes } = body

    if (!assetId || !periodId || !lotSize) {
      return NextResponse.json({ error: 'Activo, período y lotaje son requeridos' }, { status: 400 })
    }

    const trade = await db.trade.create({
      data: {
        assetId,
        periodId,
        lotSize: parseFloat(lotSize),
        notes: notes || null
      },
      include: {
        asset: true,
        period: true
      }
    })

    return NextResponse.json(trade)
  } catch (error) {
    return NextResponse.json({ error: 'Error al crear trade' }, { status: 500 })
  }
}
