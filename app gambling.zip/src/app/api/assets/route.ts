import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

// Force reload - v2

// Lista de activos por defecto
const DEFAULT_ASSETS = [
  // Forex Mayores
  { symbol: 'EURUSD', name: 'Euro / Dólar Estadounidense', category: 'forex' },
  { symbol: 'GBPUSD', name: 'Libra Esterlina / Dólar', category: 'forex' },
  { symbol: 'USDJPY', name: 'Dólar / Yen Japonés', category: 'forex' },
  { symbol: 'USDCHF', name: 'Dólar / Franco Suizo', category: 'forex' },
  { symbol: 'AUDUSD', name: 'Dólar Australiano / Dólar', category: 'forex' },
  { symbol: 'USDCAD', name: 'Dólar / Dólar Canadiense', category: 'forex' },
  { symbol: 'NZDUSD', name: 'Dólar Neozelandés / Dólar', category: 'forex' },
  
  // Forex Cruces
  { symbol: 'EURGBP', name: 'Euro / Libra Esterlina', category: 'forex' },
  { symbol: 'EURJPY', name: 'Euro / Yen Japonés', category: 'forex' },
  { symbol: 'GBPJPY', name: 'Libra Esterlina / Yen Japonés', category: 'forex' },
  { symbol: 'AUDJPY', name: 'Dólar Australiano / Yen Japonés', category: 'forex' },
  { symbol: 'EURAUD', name: 'Euro / Dólar Australiano', category: 'forex' },
  { symbol: 'EURNZD', name: 'Euro / Dólar Neozelandés', category: 'forex' },
  { symbol: 'GBPAUD', name: 'Libra Esterlina / Dólar Australiano', category: 'forex' },
  { symbol: 'GBPCAD', name: 'Libra Esterlina / Dólar Canadiense', category: 'forex' },
  
  // Índices
  { symbol: 'US100', name: 'Nasdaq 100', category: 'indices' },
  { symbol: 'US30', name: 'Dow Jones 30', category: 'indices' },
  { symbol: 'US500', name: 'S&P 500', category: 'indices' },
  { symbol: 'GER40', name: 'DAX 40 (Alemania)', category: 'indices' },
  { symbol: 'UK100', name: 'FTSE 100 (Reino Unido)', category: 'indices' },
  { symbol: 'FRA40', name: 'CAC 40 (Francia)', category: 'indices' },
  { symbol: 'JP225', name: 'Nikkei 225 (Japón)', category: 'indices' },
  { symbol: 'AUS200', name: 'ASX 200 (Australia)', category: 'indices' },
  { symbol: 'HK50', name: 'Hang Seng 50 (Hong Kong)', category: 'indices' },
  
  // Materias Primas
  { symbol: 'XAUUSD', name: 'Oro / Dólar', category: 'commodities' },
  { symbol: 'XAGUSD', name: 'Plata / Dólar', category: 'commodities' },
  { symbol: 'XBRUSD', name: 'Petróleo Brent', category: 'commodities' },
  { symbol: 'XTIUSD', name: 'Petróleo WTI (Crudo)', category: 'commodities' },
  { symbol: 'XNGUSD', name: 'Gas Natural', category: 'commodities' },
  
  // Criptos
  { symbol: 'BTCUSD', name: 'Bitcoin / Dólar', category: 'crypto' },
  { symbol: 'ETHUSD', name: 'Ethereum / Dólar', category: 'crypto' },
  { symbol: 'XRPUSD', name: 'Ripple / Dólar', category: 'crypto' },
  { symbol: 'LTCUSD', name: 'Litecoin / Dólar', category: 'crypto' },
]

// GET - Obtener todos los activos
export async function GET() {
  try {
    let assets = await db.asset.findMany({
      orderBy: [{ category: 'asc' }, { symbol: 'asc' }]
    })
    
    // Si no hay assets, crear los por defecto
    if (assets.length === 0) {
      await db.asset.createMany({
        data: DEFAULT_ASSETS
      })
      assets = await db.asset.findMany({
        orderBy: [{ category: 'asc' }, { symbol: 'asc' }]
      })
    }
    
    return NextResponse.json(assets)
  } catch (error) {
    console.error('Error en GET /api/assets:', error)
    return NextResponse.json({ error: 'Error al obtener activos', details: String(error) }, { status: 500 })
  }
}

// POST - Crear un nuevo activo
export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { symbol, name, category } = body

    if (!symbol || !name || !category) {
      return NextResponse.json({ error: 'Símbolo, nombre y categoría son requeridos' }, { status: 400 })
    }

    const asset = await db.asset.create({
      data: {
        symbol: symbol.toUpperCase(),
        name,
        category
      }
    })

    return NextResponse.json(asset)
  } catch (error) {
    return NextResponse.json({ error: 'Error al crear activo' }, { status: 500 })
  }
}
